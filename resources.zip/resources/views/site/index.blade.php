@extends('layouts.NewApp')

@section('content')
<site-table-component ></site-table-component>
@endsection
