@extends('layouts.NewApp')

@section('content')
<site-create-component></site-create-component>
@endsection
