@extends('layouts.NewManage')

@section('content')
<matrial-table-manager ></matrial-table-manager>
@endsection
