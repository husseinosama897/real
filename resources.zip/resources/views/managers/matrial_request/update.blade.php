@extends('layouts.NewManage')

@section('content')
<matrial-update-manager :data="{{$data}}"></matrial-update-manager>
@endsection
