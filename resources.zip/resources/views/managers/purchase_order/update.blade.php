@extends('layouts.NewManage')

@section('content')
<purchase-update-manager :data="{{$data}}"></purchase-update-manager>
@endsection
