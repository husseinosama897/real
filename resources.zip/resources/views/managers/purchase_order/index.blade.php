@extends('layouts.NewManage')

@section('content')
<purchase-table-manager ></purchase-table-manager>
@endsection
