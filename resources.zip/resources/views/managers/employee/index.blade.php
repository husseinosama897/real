@extends('layouts.NewManage')

@section('content')
<employee-table-manager ></employee-table-manager>
@endsection
