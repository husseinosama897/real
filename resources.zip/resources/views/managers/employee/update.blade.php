@extends('layouts.NewManage')
@section('content')
<employee-update-manager :data="{{$data}}" ></employee-update-manager>
@endsection
