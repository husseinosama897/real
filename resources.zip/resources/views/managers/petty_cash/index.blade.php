@extends('layouts.NewManage')
@section('content')
<petty_cash-table-manager ></petty_cash-table-manager>
@endsection
