@extends('layouts.NewManage')
@section('content')
<petty_cash-update-manager   :data="{{$data}}"></petty_cash-update-manager>
@endsection
