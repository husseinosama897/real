@extends('layouts.NewManage')

@section('content')
<add-user></add-user>
@endsection
