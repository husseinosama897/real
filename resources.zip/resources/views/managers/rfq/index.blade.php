@extends('layouts.NewManage')
@section('content')
<rfq-table-manager ></rfq-table-manager>
@endsection
