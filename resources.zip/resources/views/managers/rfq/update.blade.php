@extends('layouts.NewManage')
@section('content')
<rfq-update-manager   :data="{{$data}}"></rfq-update-manager>
@endsection
