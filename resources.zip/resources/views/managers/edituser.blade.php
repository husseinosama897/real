@extends('layouts.NewManage')

@section('content')
<edit-user :data="{{$data}}"></edit-user>
@endsection
