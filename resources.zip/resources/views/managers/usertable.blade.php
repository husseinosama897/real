@extends('layouts.NewManage')

@section('content')
<table-user></table-user>
@endsection
