@extends('layouts.NewManage')
@section('content')
<site-update-manager :data="{{$data}}" ></site-update-manager>
@endsection
