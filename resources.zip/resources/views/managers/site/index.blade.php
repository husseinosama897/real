@extends('layouts.NewManage')

@section('content')
<site-table-manager ></site-table-manager>
@endsection
