@extends('layouts.NewManage')
@section('content')
<subcontractor-table-manager ></subcontractor-table-manager>
@endsection
