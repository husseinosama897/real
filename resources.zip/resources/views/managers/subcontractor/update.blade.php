@extends('layouts.NewManage')
@section('content')
<subcontractor-update-manager   :data="{{$data}}"></subcontractor-update-manager>
@endsection
