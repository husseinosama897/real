@extends('layouts.NewApp')

@section('content')
<employee-create-component></employee-create-component>
@endsection
