@extends('layouts.NewApp')

@section('content')
<employee-table-component ></employee-table-component>
@endsection
