@extends('layouts.NewApp')

@section('content')
<pru-component></pru-component>
@endsection
