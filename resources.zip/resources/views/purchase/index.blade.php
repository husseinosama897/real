@extends('layouts.NewApp')

@section('content')
<table-component ></table-component>
@endsection
