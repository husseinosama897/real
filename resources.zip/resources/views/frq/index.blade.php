@extends('layouts.NewApp')

@section('content')
<frq-table-component ></frq-table-component>
@endsection
