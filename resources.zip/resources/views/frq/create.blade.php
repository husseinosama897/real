@extends('layouts.NewApp')

@section('content')
<frq-create-component></frq-create-component>
@endsection
