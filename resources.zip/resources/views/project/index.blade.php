@extends('layouts.NewManage')

@section('content')
<project-component></project-component>
@endsection
