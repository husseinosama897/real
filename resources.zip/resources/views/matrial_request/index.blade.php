@extends('layouts.NewApp')

@section('content')
<matrial-table-component ></matrial-table-component>
@endsection
