@extends('layouts.NewApp')

@section('content')

<create-matrial></create-matrial>


@endsection
