@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row justify-content-center">
    
    <img src="./index.jpg" class="rounded mx-auto d-block img-fluid" alt="Header">
    </div>
</div>
@endsection
