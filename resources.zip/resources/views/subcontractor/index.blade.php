@extends('layouts.NewApp')

@section('content')
<subcontractor-table-component ></subcontractor-table-component>
@endsection
