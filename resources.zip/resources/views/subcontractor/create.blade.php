@extends('layouts.NewApp')

@section('content')
<subcontractor-create-component></subcontractor-create-component>
@endsection
