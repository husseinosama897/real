@extends('layouts.NewApp')

@section('content')
<petty-table-component ></petty-table-component>
@endsection
