@extends('layouts.NewApp')

@section('content')
<petty-create-component></petty-create-component>
@endsection
