@component('mail::message')

{{$content}}
<a href="{{route('start')}}">
click here
</a>

Thanks,<br>
ortal-cp
@endcomponent
