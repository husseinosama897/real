<template>
 <div class="container">
     
                                <form method="POST"  v-on:submit.prevent="submit()" enctype="multipart/form-data">

        <div class="row justify-content-center">
            <div class="col-md-8">
                 <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">RFQ</h4>
                            </div>
                         
    <div class="card-body">
       


                                      	<div class="row">
									<div class="col-xl-6">
                                             <div class="form-group">
                                            <input type="text" class="form-control input-default " v-model="ref" placeholder="Ref">
                                        </div>
                                        </div>
                                                 		
                                         	<div class="col-xl-6">
                                               
                                           <div class="form-group">
                                        
                                            <input type="date" class="form-control input-rounded" v-model="date" placeholder="input-rounded">
                                        </div>

                                            </div>
                                         
                                          </div>
	<div class="row">
      
									<div class="col-xl-6">

                                             <div class="form-group">
                                            <input type="text" class="form-control input-default " v-model="subject" placeholder="subject">
                                        </div>
                                                                       </div>
                                                                            <div class="col-xl-6">
       <div class="form-group">
                                             <label for="password" class="form-label">project</label>
                                       <select class="select-form" v-model="project_id">
<option  v-for="project in projects" :key="project.id" :value="project.id"  >{{project.name}}</option>
                                       </select>
                                        </div>
                                           </div>
               </div>

<div class="row"
>
  <div class="col-xl-4">                   
                                             <div class="form-group">
                                            <input type="text" class="form-control input-default " v-model="to" placeholder="to">
                                        </div>
                                                              </div>

</div>


         

         
                                         <div class="col-xl-4">

                                        <div class="form-group">
                                             <label for="password" class="col-sm">status</label>

                                       <select class="form-select form-select-sm" aria-label=".form-select-sm example" v-model="status">
<option value="1">accept</option>
<option value="1">REJECT</option>
                                       </select>
                                        </div>
                                           </div>









                             
                                  </div>


                            </div>
                        </div>
                      <div class="form-group">
    <label for="password" class="form-label">conent</label>
<textarea class="form-control"   v-model="content" >
    
</textarea>
</div>

  </div>
   
             <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                 <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">total_amount : {{data.total - data.vat}}</h4>
                            </div>
                       
                 </div>
            </div>

                         </div>

           </div>

     <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                 <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">VAT : {{data.vat}}</h4>
                            </div>
                       
                 </div>
                 
            </div>


                         </div>

           </div>

   <div class="row justify-content-center">
          <div class="col-xl-6">
                        <div class="card">
                            <div class="card-header d-block">
                                <h4 class="card-title"> managers Comments</h4>
                           
                            </div>
                           <div class="card-body">
                                <div id="accordion-twelve" class="accordion accordion-rounded-stylish accordion-gradient">
                                    <div class="accordion__item" :key="data.id"  v-for="data in data.rfq_cycle">
                                        <template v-if="data.comment_rfq_cycle">
                                        <div class="accordion__header accordion__header--primary" data-toggle="collapse" data-target="#gradient_collapseOne"> <span class="accordion__header--icon"></span>
                                            <span class="accordion__header--text">{{data.role.name}}</span>
                                            <span class="accordion__header--indicator"></span>
                                        </div>
                                        <div id="gradient_collapseOne" class="collapse accordion__body show" data-parent="#accordion-twelve">
                                            <div class="accordion__body--text" >
                                               {{data.comment_rfq_cycle.content}}
                                            </div>
                                            
                                            <a  :href="'/uploads/rfq/'+cycle.path" v-for="cycle in data.comment_rfq_cycle.attachment_rfq_cycle" :key="cycle.id" download >  <span class="badge badge-pill badge-danger">
                                                file
                                                </span></a>
                                        </div>
                                        </template>
                                    </div>
                              
                                </div>
                            </div>
                        </div>
                    </div>
  <div class="col-xl-6">
                            <div class="card">
                                                       <div class="card-header d-block">
                                <h4 class="card-title"> add your comment</h4>
                                <p class="m-0 subtitle">Add <code>comments</code> and <code>attachments</code></p>
                            </div>    
                            <div class="form-group">
                              
                                 <textarea v-model="contentmanager"    placeholder="content"     class="form-control" > 
                                 </textarea>
                               

		<label class="col-sm" > files  :</label>
										<div class="col-sm">
	<input type="file"   v-on:change="onImageChange($event)" >
                                        </div>
                                </div>
                         
                            </div>
  </div>
                      
     <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                 <div class="card">
                            <div class="card-header">

                                <button class="btn btn-primary"  type="submit">
                              
                              submit
                            </button>
                                 <button   @click="reset()" class="btn btn-danger"  type="button">
                              
                              reset
                            </button>



                            </div>

                 </div>
            </div>
        </div>

           </div>

            </div>
           
       </form>
       
                        
                                                          <div id="editEmployeeModal" class="modal fade bd-example-modal-sm" style="overflow:auto;">
    <div class="modal-dialog ">
      <div class="modal-content" style="overflow:auto;">
                <button style="color:black" type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span style="color:black" aria-hidden="true">&times;</span>
        </button>
      
      <div class="alert alert-success" role="alert">
  <h4 class="alert-heading">Done !</h4>
  <p>Process has been submitted successfully</p>
  <hr>
<input type="button" class="btn btn-dark" data-dismiss="modal" value="close">
</div>
      </div>
    </div>
  </div>


                             <div id="deathEmployeeModal" class="modal fade bd-example" style="overflow:auto;">
    <div class="modal-dialog ">
      <div class="modal-content" style="overflow:auto;">
     
      
      <div class="alert alert-danger" role="alert">
  <h4 class="alert-heading"> فشلت العمليه  !</h4>
  <p>    :  لقد فشلت العمليه للاسباب التاليه </p>
    <p v-for="(err,index)  in allerros" :key="index"> {{err}}</p>
  <hr>
<input type="button" class="btn btn-dark" data-dismiss="modal" value="الغاء">
</div>
      </div>
    </div>
       </div>

                         </div>
             

</template>

<script>

    export default {
props:['data'],
        data(){
return{

quotation:'',
project_id:'',
products:[{}],
projects:
[],
allerros:[],
status:'',
condition:[{}],
date:'',
subject:'',
content:'',
images:[],
cc:'',
ref:'',
userz:[],

choice:[],
to:'',
contentmanager:'',
matrial_request_cycle:[],
transportation:'',
delivery_date:'',
material_avalibility:'',
subject:'',
}

        },

        methods:{
                                               project(){
    
axios({
    url:'/selectproject',
    method:'get',
}).then(res=>{
    
    	 if(Array.isArray(res.data.data)){
     

                    res.data.data.forEach(n=>{
                         n.forEach(z=>{
this.projects.push(z)
                    })
                        })
                 }else{

let vm = []

                   Object.keys(res.data.data).map((n)=>{

                this.projects.push(res.data.data[n])
                     })

                 }

})
},

              onImageChange(e) {     
this.images.push(e.target.files[0])
            },

         deleteuser(index){
                this.userz.splice(index,1)
            }
,
takethischoice(user){
this.userz.push(user)
   this.choice.splice(0)
},

users(){
    this.choice.splice(0)
    axios({
        url:'/user/userautocomplete',
        method:'post',
        data:{
            name:this.cc
        }
    }).then(res=>{
        this.choice = res.data.data
    })
},
reset(){
    
this.quotation = '',
this.project_id = 1,
this.products = [{}],
this.allerros = [],
this.condition = [{}],
this.date = '',
this.subject = '',
this.content = '',
this.cc = '',
this.ref = '',
this.userz = [],

this.choice = [],
this.to = '',
this.transportation= '',
this.delivery_date = '',
this.material_avalibility = '',
this.subject = ''
},

submit(){

      	const config = {

                    headers: { 'content-type': 'multipart/form-data' }

                }

                let formData = new FormData();

if(this.project_id){
	 formData.append('project_id', this.project_id);
}
if(this.quotation){
	 formData.append('quotation', this.quotation);
}
if(this.images){
	 formData.append('count', this.images.length);
}


this.images.forEach((element, index, array) => {
	if(element !== undefined){
 formData.append('files-' + index, element);
	}
     
    });

if(this.contentmanager > 0){
	 formData.append('contentmanager', JSON.stringify(this.contentmanager));
}



if(this.date){
	 formData.append('date', this.date);
}

if(this.subject){
	 formData.append('subject', this.subject);
}
if(this.content){
	 formData.append('content', this.content);
}

if(this.ref){
	 formData.append('ref', this.ref);
}

if(this.status){
	 formData.append('status', this.status);
}

if(this.to){
	 formData.append('to', this.to);
}


if(this.userz.length > 0){
	 formData.append('users', JSON.stringify(this.userz));
}
    axios.post('/managers/action_rfq/'+this.data.id,formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data' },
})
.then(res=>{
    window.$("#editEmployeeModal").modal("show");
this.quotation = '',
this.project_id = '',
this.products = [{}],
this.allerros = [],
this.condition = [{}],
this.date = '',
this.contentmanager='',
this.subject = '',
this.content = '',
this.cc = '',
this.ref = '',
this.userz = [],

this.choice = [],
this.to = '',
this.transportation= '',
this.delivery_date = '',
this.material_avalibility = '',
this.subject = ''
}).catch(error=>{
 if (error.response.status == 422){
     if(Array.isArray(error.response.data.errors)){
         this.allerros = error.response.data.errors;
     }else{
         try {
  this.allerros = JSON.parse(error.response.data.message);
         }
         catch{
                this.allerros = error.response.data.errors;
         }
     }
window.$("#deathEmployeeModal").modal("show"); 
       
      }
    })
},

addproduct(){
    this.products.push({})
},
removeproduct(index){
this.products.splice(index,1)
}
 ,
 
 addcondition(){
    this.condition.push({})
},
removecondition(index){
this.condition.splice(index,1)
}
 
 },
        mounted() {
       this.project()
this.project_id = this.data.project_id,
this.products = this.data.attributes,
this.condition = this.data.note,
this.date =this.data.date,
this.subject = this.data.subject,
this.content = this.data.content,
this.ref = this.data.ref,
this.matrial_request_cycle = this.data.matrial_request_cycle ?? []
this.to = this.data.to


        },
     
    }
</script>
