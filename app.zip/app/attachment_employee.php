<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class attachment_employee extends Model
{
    //
}
