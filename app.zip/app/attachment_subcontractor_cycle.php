<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class attachment_subcontractor_cycle extends Model
{
    //
}
