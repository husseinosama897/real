<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class attachment_matrial_cycle extends Model
{
    //
}
