<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class attachment_petty_cash_cycle extends Model
{
    //
}
