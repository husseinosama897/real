<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class petty_attr extends Model
{
    //
}
