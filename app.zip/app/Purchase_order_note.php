<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Purchase_order_note extends Model
{
    //
}
