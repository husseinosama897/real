<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class managerslettercontroller extends Controller
{
    //
}
