<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class attachment_site_cycle extends Model
{
    //
}
