<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class subcontractor_attr extends Model
{
    //
}
