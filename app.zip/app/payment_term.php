<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class payment_term extends Model
{
    //
}
