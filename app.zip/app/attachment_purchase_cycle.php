<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class attachment_purchase_cycle extends Model
{
    //
}
