<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class attachment_letter_cycle extends Model
{
    //
}
