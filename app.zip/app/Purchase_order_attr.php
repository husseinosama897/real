<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Purchase_order_attr extends Model
{
    //
}
