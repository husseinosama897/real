<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class purchase_order_attachment extends Model
{
    //
}
